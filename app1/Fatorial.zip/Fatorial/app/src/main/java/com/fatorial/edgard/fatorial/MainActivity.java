package com.fatorial.edgard.fatorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button botao = (Button) findViewById(R.id.button);
        final EditText input = (EditText) findViewById(R.id.editText);
        final TextView resultado = (TextView) findViewById(R.id.resultado);

        botao.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    int x = Integer.parseInt(input.getText().toString());
                    int result = 1;

                    for(x=x;x>=2;x--){
                        result = result * x;
                    }

                    resultado.setText(" "+result);
                }
        });
    }
}
